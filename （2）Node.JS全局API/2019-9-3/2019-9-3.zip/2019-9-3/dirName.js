/**
 * 全局api，直接调用即可
 */
console.log(__dirname);
console.log(__filename);